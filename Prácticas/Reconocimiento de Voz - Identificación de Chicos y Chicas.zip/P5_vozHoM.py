# Reconocedor de audio entre hombre y mujer

from scipy.io import wavfile
from matplotlib import pyplot as plt
from winsound import *

import pyaudio 
import wave
import numpy as np

plt.close('all')

#Parametros de grabacion 
formato = pyaudio.paInt16
canales = 1
tasa_muestreo = 44100 #Señal mioelectrica 4000  y para audio de alta calidad 44100, mp3 
#pedazos de 1024 datos de la tasa de muestreo
tamano_bloque = 1024 # Señal de voz buscar la frecuencia 2 veces arriba de la frecuencia base el muestreo es mejor si se toma mayor a 2 veces la frecuencia base 
tiempo_grabacion = 3
nombre_archivo = 'voz.wav'

#Grabacion
audio = pyaudio.PyAudio() # Permite generar objetos de audio 
try: # excepciones del codigo para que no se trabe la maquina, para verificar si esta libre la computadora
    flujo_sonido = audio.open(format = formato, channels = canales, rate = tasa_muestreo, input = True, frames_per_buffer = tamano_bloque)# Abre el objeto, formato, numero de canales, la tasa de muestreo,inicie la entrada, tamaño de buffer
    print('Inicia la grabacion')
    datos_audio = []
    fragmentos = []
    for i in range(0,int(tasa_muestreo/tamano_bloque*tiempo_grabacion)):
        datos_bloque = flujo_sonido.read(tamano_bloque)#Tomando lo que hay en el buffer de la computadora 
        datos_audio.append(datos_bloque)  
        fragmentos.append(np.frombuffer(datos_bloque,dtype = np.int16))
    senal_audio = np.hstack(fragmentos)
    if np.max(np.abs(senal_audio))!=0:
        senal_audio = senal_audio/np.max(np.abs(senal_audio))*32767 #Esto sirve para aumentar la señal ya que esta solamente en un rango de 1 y -1, aumentas el volumen
        senal_audio = senal_audio.astype(np.int16)
    print('Termina la Grabacion')
    flujo_sonido.stop_stream()
    flujo_sonido.close()
finally:
    audio.terminate()

archivo_wave=wave.open(nombre_archivo,'wb')
archivo_wave.setnchannels(canales)
archivo_wave.setsampwidth(audio.get_sample_size(formato))
archivo_wave.setframerate(tasa_muestreo)
archivo_wave.writeframes(b''.join([senal_audio.tobytes()]))
archivo_wave.close()

def calcular_frecuencia_fundamental(filename):
    
    samplerate, data = wavfile.read(filename)
    
    if len(data.shape) > 1:
        data = data.mean(axis=1)

    duracion_segmento = 0.01  
    tamano_segmento = int(duracion_segmento * samplerate)
    
    frecuencias_fundamentales = []

    for inicio in range(0, len(data) - tamano_segmento, tamano_segmento):
        segmento = data[inicio:inicio + tamano_segmento]

        fft_vals = np.abs(np.fft.fft(segmento))[:tamano_segmento // 2]
        freqs = np.fft.fftfreq(len(segmento), 1 / samplerate)[:tamano_segmento // 2]

        rango_vocal = (freqs > 50) & (freqs < 300)
        freqs_rango_vocal = freqs[rango_vocal]
        fft_rango_vocal = fft_vals[rango_vocal]

        if len(fft_rango_vocal) > 0:
            freq_fundamental = freqs_rango_vocal[np.argmax(fft_rango_vocal)]
            frecuencias_fundamentales.append(freq_fundamental)

    if frecuencias_fundamentales:
        frecuencia_promedio = np.mean(frecuencias_fundamentales)
        print(f"Frecuencia fundamental promedio: {frecuencia_promedio:.2f} Hz")
        return frecuencia_promedio
    else:
        print("No se detectaron frecuencias en el rango vocal.")
        return None

def clasificar_genero(frecuencia_promedio):
    if frecuencia_promedio is None:
        print("No se pudo clasificar la voz.")
    elif frecuencia_promedio < 160:
        print("La voz es de un hombre.")
    else:
        print("La voz es de una mujer.")

archivo_audio = nombre_archivo 
frecuencia_promedio = calcular_frecuencia_fundamental(archivo_audio)
clasificar_genero(frecuencia_promedio)