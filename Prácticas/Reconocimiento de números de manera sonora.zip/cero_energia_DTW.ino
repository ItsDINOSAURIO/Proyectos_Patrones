// Librerías
#include <SPI.h>
#include <SD.h>
#include <SoftwareSerial.h>

// Configuración para Serial1 en pines 8 (Rx) y 9 (Tx)
//SoftwareSerial BTSerial(11, 12); 

// Vars globales
int step = 0;
int win_len = 0;
int n_windows = 1;

// Vars para los cálculos con memoria dinámica
float window[882];
double* energy = nullptr;
double* zcr = nullptr;
double** test_feats = nullptr;
double* costs = nullptr;
// Parámetros de ventana
int window_idx = 0;
int window_C = 0;

bool params_received = false;
int selectedClass = -1;

void liberarMemoria() {
  if (energy) {
    free(energy);
    energy = nullptr;
  }
  if (zcr) {
    free(zcr);
    zcr = nullptr;
  }
  if (costs) {
    free(costs);
    costs = nullptr;
  }
  if (test_feats) {
    for (int i = 0; i < n_windows; i++) {
      if (test_feats[i]) {
        free(test_feats[i]);
        test_feats[i] = nullptr;
      }
    }
    free(test_feats);
    test_feats = nullptr;
  }
}

// Función que al recibir parámetros indica el comienzo del código
void recibirParametros() {
  if (Serial1.available() > 0) {
    String input =  Serial1.readStringUntil('\n');
    input.trim();
    Serial.print("Entrada recibida: '");
    Serial.print(input);
    Serial.println("'");

    int comma1 = input.indexOf(',');
    int comma2 = input.lastIndexOf(',');

    if (comma1 > 0 && comma2 > comma1) {
      step = input.substring(0, comma1).toInt();
      win_len = input.substring(comma1 + 1, comma2).toInt();
      n_windows = input.substring(comma2 + 1).toInt();

      // Validar parámetros
      if (step <= 0 || win_len <= 0 || n_windows <= 0) {
        Serial.println("Error: Parámetros inválidos recibidos.");
        Serial1.println("0");
        return;
      }

      // Liberar memoria previa si existe
      liberarMemoria();

      energy = (double*)calloc(n_windows, sizeof(double));
      zcr = (double*)calloc(n_windows, sizeof(double));
      test_feats = (double*)calloc(n_windows, sizeof(double));
      costs = (double*)calloc(n_windows, sizeof(double));

      if (energy && zcr && test_feats && costs) {
        for (int i = 0; i < n_windows; i++) {
          test_feats[i] = (double*)calloc(2, sizeof(double));
          if (!test_feats[i]) {
            Serial.println("Error: Memoria insuficiente.");
            Serial1.println("0");
            liberarMemoria();
            return;
          }
        }

        params_received = true;
        Serial.println("Parámetros recibidos correctamente.");
        Serial.print("step: "); Serial.print(step);
        Serial.print(", win_len: "); Serial.print(win_len);
        Serial.print(", n_windows: "); Serial.println(n_windows);
        Serial1.println("1");
      } else {
        Serial.println("Error: Memoria insuficiente.");
        Serial1.println("0");
      }
    } else {
      Serial.println("Error: Formato de parámetros inválido.");
    }
  }
}

//Función para guardar los datos recopilados del test
void gTest() {
  for (int i = 0; i < window_C; i++) {
    test_feats[i][0] = energy[i];
    test_feats[i][1] = zcr[i];
  }
}

void calcularDTW(int clase_actual, double csv_energy, double csv_zcr, double** dtw, double& min_costoT, int& Clase_det) {
  const int TOL_WIN = 5;

  for (int idx = 0; idx < window_C; idx++) {
    // Usar dos filas para optimización de memoria
    double* prev_row = (double*)malloc((step + 1) * sizeof(double));
    double* curr_row = (double*)malloc((step + 1) * sizeof(double));

    if (!prev_row || !curr_row) {
      Serial.println("Error: No se pudo asignar memoria para DTW optimizado.");
      if (prev_row) free(prev_row);
      if (curr_row) free(curr_row);
      return;
    }

    // Inicializar la fila previa
    for (int j = 0; j <= step; j++) prev_row[j] = (j == 0) ? 0 : INFINITY;

    // Calcular DTW
    for (int i = 1; i <= step; i++) {
      curr_row[0] = INFINITY;
      for (int j = max(1, i - TOL_WIN); j <= min(step, i + TOL_WIN); j++) {
        double cost = sqrt(pow(csv_energy - test_feats[idx][0], 2) + pow(csv_zcr - test_feats[idx][1], 2));
        curr_row[j] = cost + min(min(prev_row[j], curr_row[j - 1]), prev_row[j - 1]);
      }
      // Intercambiar filas
      double* temp = prev_row;
      prev_row = curr_row;
      curr_row = temp;
    }

    double final_cost = prev_row[step];
    if (isfinite(final_cost) && final_cost < costs[idx]) {
      costs[idx] = final_cost;
    }

    free(prev_row);
    free(curr_row);

    Serial.print("Ventana "); Serial.print(idx);
    Serial.print(" | Costo: "); Serial.println(final_cost);
  }

  // Calcular el costo total para la clase actual
  double total_cost = 0;
  for (int i = 0; i < window_C; i++) {
    if (isfinite(costs[i])) {
      total_cost += costs[i];
      Serial.print("Costo acumulado para ventana "); Serial.print(i);
      Serial.print(": "); Serial.println(costs[i]);
    } else {
      Serial.print("Costo inválido en ventana "); Serial.println(i);
    }
  }

  Serial.print("Costo total para clase "); Serial.print(clase_actual);
  Serial.print(": "); Serial.println(total_cost);

  // Si el costo total es menor, actualizar la clase detectada
  if (total_cost < min_costoT) {
    min_costoT = total_cost;
    Clase_det = clase_actual;
  }
}


void aCSV() {
  Serial.println("Analizando base de datos...");
  File DB = SD.open("database.csv");
  if (!DB) {
    Serial.println("Error al abrir 'database.csv'.");
    return;
  }

  double min_costoT = INFINITY;
  int Clase_det = -1;

  // Validar valores de 'step'
  if (step > 50) {
    Serial.println("Error: El valor de 'step' es demasiado grande.");
    DB.close();
    return;
  }

  // Asignar memoria para DTW
  double** dtw = (double*)malloc((step + 1) * sizeof(double));
  if (dtw == NULL) {
    Serial.println("Error: No se pudo asignar memoria para DTW.");
    DB.close();
    return;
  }

  for (int i = 0; i <= step; i++) {
    dtw[i] = (double*)malloc((step + 1) * sizeof(double));
    if (dtw[i] == NULL) {
      Serial.println("Error: Fallo en la asignación de memoria.");
      break;
      for (int j = 0; j < i; j++) {
        free(dtw[j]);
      }
      free(dtw);
      DB.close();
      return;
    }
  }

  // Procesar las clases
  int clases[10];
  int num_clases = 0;

  DB.seek(0);
  while (DB.available()) {
    String linea = DB.readStringUntil('\n');
    linea.trim();
    if (linea.length() == 0) continue;

    int coma1 = linea.indexOf(',');
    if (coma1 == -1) continue;

    String classLabelStr = linea.substring(0, coma1);
    if (classLabelStr == "Class") continue;

    int classLabel = classLabelStr.toInt();

    bool nueva_clase = true;
    for (int i = 0; i < num_clases; i++) {
      if (clases[i] == classLabel) {
        nueva_clase = false;
        break;
      }
    }
    if (nueva_clase) {
      if (num_clases >= 10) {
        Serial.println("Número máximo de clases alcanzado.");
        break;
      }
      clases[num_clases++] = classLabel;
    }
  }

  Serial.print("Clases detectadas: ");
  for (int i = 0; i < num_clases; i++) {
    Serial.print(clases[i]);
    Serial.print(" ");
    delay(10);
  }
  Serial.println();

  for (int idx_clase = 0; idx_clase < num_clases; idx_clase++) {
    int clase_actual = clases[idx_clase];
    DB.seek(0);
    Serial.print("Analizando clase: ");
    Serial.println(clase_actual);

    while (DB.available()) {
      String linea = DB.readStringUntil('\n');
      linea.trim();

      int coma1 = linea.indexOf(',');
      int coma2 = linea.lastIndexOf(',');
      if (coma1 == -1 || coma2 == -1) continue;

      if (linea.substring(coma1 + 1, coma2) == "Energy" || 
          linea.substring(coma2 + 1) == "ZCR" || 
          linea.substring(0, coma1) == "Class") {
        continue;
      }

      double csv_energy = linea.substring(coma1 + 1, coma2).toDouble();
      double csv_zcr = linea.substring(coma2 + 1).toDouble();
      int classLabel = linea.substring(0, coma1).toInt();

      if (classLabel == clase_actual) {
        calcularDTW(clase_actual, csv_energy, csv_zcr, dtw, min_costoT, Clase_det);
      }
    }
  }

  DB.close();

  // Liberar memoria de DTW
  for (int i = 0; i <= step; i++) {
    free(dtw[i]);
  }
  free(dtw);

  Serial.print("El número es: ");
  Serial1.print("RESULTADO:");
  Serial.println(Clase_det);
  Serial1.print(Clase_det);
  Serial.println("Fin de procesamiento.......");
}

void procesarDatos() {
  Serial1.println("3");
  Serial.print("Esperando datos...");Serial.println(window_idx);
  delay(20);
  if (Serial1.available() > 0) {
    String input = Serial1.readStringUntil('\n');
    input.trim();

    if (input == "4") {
      Serial.println("Cambio de ventana recibido.");
      return;
    }

    double sample = input.toDouble();
    Serial.println(sample,6);

    if (window_idx == step) {
      Serial1.println("4");
      Serial.println("Procesando ventana......");

      double c_energy = 0.0, c_zcr = 0.0;

      for (int i = 0; i < step; i++) {
        c_energy += window[i] * window[i];
      }

      for (int i = 1; i < step; i++) {
        if ((window[i - 1] > 0 && window[i] < 0) || (window[i - 1] < 0 && window[i] > 0)) {
          c_zcr++;
        }
      }

      if (window_C < n_windows) {
        energy[window_C] = c_energy;
        zcr[window_C] = c_zcr;
        Serial.print("Ventana "); Serial.print(window_C);
        Serial.print(" | Energía: "); Serial.print(c_energy);
        Serial.print(" | ZCR: "); Serial.println(c_zcr);
        window_C++;
      } else {
        Serial.println("No se puede incrementar window_C: límite alcanzado.");
      }

      Serial.print("Estado actual: window_idx="); Serial.print(window_idx);
      Serial.print(", window_C="); Serial.print(window_C);
      Serial.print(", n_windows="); Serial.println(n_windows);

      window_idx = 0;
    }

    if (input == "2") {
      Serial.println("Datos listos para analizar.");
      aCSV();
    } else {
      window[window_idx++] = sample;
    }
  }
}

void setup() {
  Serial.begin(9600);
  Serial1.begin(9600);     // Velocidad de comunicación del HC-06
  if (!SD.begin(10)) {
    Serial.println("Error inicializando la tarjeta SD.");
    while (1);
  }
  Serial.println("Sistema iniciado.");
}

void loop() {
  if (!params_received) {
    recibirParametros();
  } else {
    procesarDatos();
  }
}